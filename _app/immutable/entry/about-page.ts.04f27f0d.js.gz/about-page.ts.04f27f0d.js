import{c as p,p as s}from"../chunks/_page.57618ffe.js";export{p as csr,s as prerender};
