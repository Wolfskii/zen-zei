import{_ as r}from"./_page.57618ffe.js";import{default as t}from"../entry/about-page.svelte.7c6504ad.js";export{t as component,r as universal};
