import{default as t}from"../entry/error.svelte.7201b688.js";export{t as component};
