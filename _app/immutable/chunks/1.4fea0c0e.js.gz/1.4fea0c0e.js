import{default as t}from"../entry/error.svelte.72343fde.js";export{t as component};
