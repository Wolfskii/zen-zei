import{default as t}from"../entry/_layout.svelte.087dca3e.js";export{t as component};
