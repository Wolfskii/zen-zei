var s;const a=((s=globalThis.__sveltekit_syn3me)==null?void 0:s.base)??"/zen-zei";var e;const t=((e=globalThis.__sveltekit_syn3me)==null?void 0:e.assets)??a;export{t as a,a as b};
