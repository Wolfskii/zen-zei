import{default as t}from"../entry/error.svelte.9e6042ae.js";export{t as component};
