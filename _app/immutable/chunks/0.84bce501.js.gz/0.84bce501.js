import{default as t}from"../entry/_layout.svelte.2c8478ed.js";export{t as component};
