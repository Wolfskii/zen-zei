import{default as t}from"../entry/_layout.svelte.009ca60b.js";export{t as component};
