import{_ as r}from"./_page.da46b06b.js";import{default as t}from"../entry/_page.svelte.4dc662ee.js";export{t as component,r as universal};
