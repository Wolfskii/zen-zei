const e=!1,r=!0,t=Object.freeze(Object.defineProperty({__proto__:null,csr:!1,prerender:!0},Symbol.toStringTag,{value:"Module"}));export{t as _,e as c,r as p};
