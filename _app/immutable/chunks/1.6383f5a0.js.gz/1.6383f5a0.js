import{default as t}from"../entry/error.svelte.a6440005.js";export{t as component};
